(function (w, t) {
    w[t] = ['ngRoute', 'myApp.shop', 'myApp.table',]
}(window, 'FuncPermissions'))

